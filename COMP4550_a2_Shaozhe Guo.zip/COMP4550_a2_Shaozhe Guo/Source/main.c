#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"
#include "discoveryf4utils.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "croutine.h"
#include "main.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

GPIO_InitTypeDef GPIO_Initstructure;
TIM_TimeBaseInitTypeDef timer_InitStructure;
TaskHandle_t xMasterThreadHandler = NULL;

unsigned int buttonHoldTime = 0;
unsigned int buttonReleaseTime = 0;
bool buttonUp = true;
bool isDoubleClick = false;
bool singleClick = false;
bool doubleClick = false;
bool longClick = false;

mode currMode;
uint16_t countDownLED = 0;
int blinkNum = 0;
int coffeeIndex = 0;
int ingredientIndex = 0;

int milkTime = 5;
int espressoTime = 5;
int chocolateTime = 6;
int secondAdd = 0;

fir_8 filt;
bool enableSound = false;
int soundTimer = 0;
bool start_sound_timer = false;
bool sound_init = false;

bool changeValve = false;
uint32_t currValvePos = VALVE_OFF;

void InitLEDs() {
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

  GPIO_Initstructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_Initstructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_Initstructure.GPIO_OType = GPIO_OType_PP;
  GPIO_Initstructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Initstructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_Init(GPIOD, & GPIO_Initstructure);
}

void InitButton() {// initialize user button
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

  GPIO_Initstructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_Initstructure.GPIO_OType = GPIO_OType_PP;
  GPIO_Initstructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_Initstructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Initstructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_Init(GPIOA, & GPIO_Initstructure);
}

void InitTimers() {
	//initialize timer2
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

  timer_InitStructure.TIM_Prescaler = 232;
  timer_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
  timer_InitStructure.TIM_Period = 2999;
  timer_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  timer_InitStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM2, & timer_InitStructure);
  TIM_Cmd(TIM2, ENABLE);
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	
	//initialize timer3
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	timer_InitStructure.TIM_Prescaler = 2100 - 1;
	timer_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	timer_InitStructure.TIM_Period = 10000 - 1;
	timer_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	timer_InitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &timer_InitStructure);
	TIM_Cmd(TIM3, ENABLE);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
}

void EnableTimer2Interrupt() {
  NVIC_InitTypeDef nvicStructure;
  nvicStructure.NVIC_IRQChannel = TIM2_IRQn;
  nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
  nvicStructure.NVIC_IRQChannelSubPriority = 1;
  nvicStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init( & nvicStructure);
}

void EnableTimer3Interrupt() {
  NVIC_InitTypeDef nvicStructure;
  nvicStructure.NVIC_IRQChannel = TIM3_IRQn;
  nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
  nvicStructure.NVIC_IRQChannelSubPriority = 1;
  nvicStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init( & nvicStructure);
}

void InitSound() {
	SystemInit();

	//enables GPIO clock for PortD
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOD, &GPIO_InitStructure);

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

	codec_init();
	codec_ctrl_init();

	I2S_Cmd(CODEC_I2S, ENABLE);

	initFilter(&filt);
}

// the following code is for sound
// a very crude FIR lowpass filter
float updateFilter(fir_8* filt, float val) {
	uint16_t valIndex;
	uint16_t paramIndex;
	float outval = 0.0;

	valIndex = filt->currIndex;
	filt->tabs[valIndex] = val;

	for (paramIndex=0; paramIndex<8; paramIndex++)
	{
		outval += (filt->params[paramIndex]) * (filt->tabs[(valIndex+paramIndex)&0x07]);
	}
	valIndex++;
	valIndex &= 0x07;

	filt->currIndex = valIndex;

	return outval;
}

void initFilter(fir_8* theFilter) {
	uint8_t i;

	theFilter->currIndex = 0;

	for (i=0; i<8; i++)
		theFilter->tabs[i] = 0.0;

	theFilter->params[0] = 0.01;
	theFilter->params[1] = 0.05;
	theFilter->params[2] = 0.12;
	theFilter->params[3] = 0.32;
	theFilter->params[4] = 0.32;
	theFilter->params[5] = 0.12;
	theFilter->params[6] = 0.05;
	theFilter->params[7] = 0.01;
}

void InitServo(void) {
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	//Initialize PB6 (TIM4 Ch1)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; // GPIO_High_Speed
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	// Assign Alternate Functions to pins
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_TIM4);
}
	
void InitPWMTimer4(void) {
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	//TIM4 Clock Enable
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	// Time Base Configuration for 50Hz
	TIM_TimeBaseStructure.TIM_Period = 20000 - 1;
	TIM_TimeBaseStructure.TIM_Prescaler = 84 -1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
	TIM_Cmd(TIM4, ENABLE);
}
	
void SetupPWM(void) {
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //Set output capture as PWM mode
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //Enable output compare
	TIM_OCInitStructure.TIM_Pulse = 0; // Initial duty cycle at 0%
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // HIGH output compare active
	// Set the output capture channel 1 and 2 (upto 4)
	TIM_OC1Init(TIM4, &TIM_OCInitStructure); // Channel 1
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_OC2Init(TIM4, &TIM_OCInitStructure); // Channel 2
	TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM4, ENABLE);
}

void TIM2_IRQHandler() {
  if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    
		buttonHoldTime++;
    buttonReleaseTime++;
	
    if (!buttonUp && buttonHoldTime >= LONG_PRESS_TIME * 120) {
      singleClick = false;
			longClick = true;
      buttonHoldTime = 0;
    }

		if(enableSound)soundTimer++;
		
		if(soundTimer > SOUND_OUTPUT * 120)
		{
			enableSound = false;
			soundTimer = 0;
		}	
  }
}

void TIM3_IRQHandler() {
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		if ( blinkNum > 0 ) {
			GPIO_ToggleBits(GPIOD, countDownLED);
			blinkNum--;
		}
	}
}

void UpdateIngredientTiming() {
	if (ingredientIndex == MOCHA) chocolateTime = secondAdd;
	else if (ingredientIndex == ESPRESSO) espressoTime = secondAdd;
	else if (ingredientIndex == LATTE) milkTime = secondAdd;
	secondAdd=0;
}

void UpdateTimingStatus() {
	isDoubleClick = buttonReleaseTime <= DOUBLE_CLICK_TIME * 120;
	
	if (singleClick && !isDoubleClick) {
		secondAdd++;
		singleClick = false;
	} else if (doubleClick) {
		doubleClick = false;
	} else if (longClick) {
		currMode = programming;
		singleClick = false;
		doubleClick = false;
		longClick = false;
		buttonUp = true;
		if(secondAdd>0)
			UpdateIngredientTiming();
	}
}

void UpdateProgrammingStatus() {
	isDoubleClick = buttonReleaseTime <= DOUBLE_CLICK_TIME * 120;
	if (singleClick && !isDoubleClick) {
		ingredientIndex = (ingredientIndex + 1) % 3;
		singleClick = false;
	} else if (doubleClick) {
		doubleClick = false;
		DisplayCountdown();
		while(blinkNum){}
		currMode = updateTime;
	} else if (longClick) {
		currMode = brewing;
		singleClick = false;
		doubleClick = false;
		longClick = false;
		buttonUp = true;
		LED_GREEN_OFF;
	}
}

void UpdateBrewingStatus() {
	isDoubleClick = buttonReleaseTime <= DOUBLE_CLICK_TIME * 120;
	
	if(singleClick && !isDoubleClick) {
		coffeeIndex = (coffeeIndex + 1) % 3;
		ingredientIndex = coffeeIndex;
		singleClick = false;
	} else if (doubleClick) {	
		if (coffeeIndex == MOCHA) {
			xTaskCreate( vDispenseMocha, (const char*)"Dispense Coffee",
				128, NULL, 0, NULL);
		} else if (coffeeIndex == ESPRESSO) {		
			xTaskCreate( vDispenseEspresso, (const char*)"Dispense Coffee",
				128, NULL, 0, NULL);
		} else if (coffeeIndex == LATTE) {	
			xTaskCreate( vDispenseLatte, (const char*)"Dispense Coffee",
				128, NULL, 0, NULL);
		}
		currMode = making;
		singleClick = false;
		doubleClick = false;
		coffeeIndex = MOCHA;
	} else if (longClick) {
		currMode = programming;
		singleClick = false;
		doubleClick = false;
		longClick = false;
		buttonUp = true;
	}
}

void UpdateIdleModeStatus() {
	if (singleClick) {
		currMode = brewing;
		singleClick = false;
	} else if (longClick) {
		currMode = programming;
		singleClick = false;
		doubleClick = false;
		longClick = false;
		buttonUp = true;
	}
}

void UpdateMakingStatus() {
	if(singleClick) {
		currMode = brewing;
		singleClick = false;
	} else if(longClick) {
		singleClick = false;
		longClick = false;
	} else if(doubleClick) {
		singleClick = false;
		doubleClick = false;
	}
}

void UpdateMachineStatus() {
	switch (currMode) {
		case idleMode:
			UpdateIdleModeStatus();
			break;
		case brewing:
			UpdateBrewingStatus();
			break;
		case programming:
			UpdateProgrammingStatus();
			break;
		case updateTime:
			UpdateTimingStatus();
			break;
		case making:
			UpdateMakingStatus();
			break;
		default:
			break;
	}
}

void DisplayCountdown() {
	if (ingredientIndex == MOCHA) {
		countDownLED = MOCHA_LED;
		blinkNum = chocolateTime * 2;	
	}	else if (ingredientIndex == ESPRESSO) {
		countDownLED = ESPRESSO_LED;
		blinkNum = espressoTime * 2;
	}	else if (ingredientIndex == LATTE) {
		countDownLED = LATTE_LED;
		blinkNum = milkTime * 2;
	}
}

void ShowUpdateTimingLED() {
	LED_GREEN_ON;
	if (ingredientIndex == MOCHA) {
		if ( buttonUp ) {
			LED_MOCHA_ON;
		} else{
			LED_MOCHA_OFF;
		}
	} else if (ingredientIndex == ESPRESSO) {
		if ( buttonUp ) {
			LED_ESPRESSO_ON;
		} else{
			LED_ESPRESSO_OFF;
		}
	} else if (ingredientIndex == LATTE) {
		if ( buttonUp ) {
			LED_LATTE_ON;
		} else{
			LED_LATTE_OFF;
		}
	}
}

void ShowProgrammingLED() {
	LED_MOCHA_OFF;
	LED_ESPRESSO_OFF;
	LED_LATTE_OFF;
	if (ingredientIndex == MOCHA) {
		LED_MOCHA_ON;
	} else if (ingredientIndex == ESPRESSO) {
		LED_ESPRESSO_ON;
	} else if (ingredientIndex == LATTE) {
		LED_LATTE_ON;
	}
	LED_GREEN_ON;
}

void ShowSelectingLED() {
	LED_GREEN_OFF;
	LED_MOCHA_OFF;
	LED_ESPRESSO_OFF;
	LED_LATTE_OFF;
	if (coffeeIndex == MOCHA) {
		LED_MOCHA_ON;
	} else if (coffeeIndex == ESPRESSO) {
		LED_ESPRESSO_ON;
	} else if (coffeeIndex == LATTE) {
		LED_LATTE_ON;
	}
}

void ShowIdleModeLED() {
	LED_BLUE_OFF;
	LED_RED_OFF;
	LED_ORANGE_OFF;
	LED_GREEN_ON;
}

void ShowLED() {
	switch (currMode) {
		case idleMode:
			ShowIdleModeLED();
			break;
		case brewing:
			ShowSelectingLED();
			break;
		case programming:
			ShowProgrammingLED();
			break;
		case updateTime:
			ShowUpdateTimingLED();
			break;
		case making:
			break;
		default:
			break;
	};
}

void ResetValve(){
	currValvePos = VALVE_OFF;
	changeValve = true;	
}

void OutputSound(int number){
	int i;
	for (i=0;i<number;i++){
		enableSound = true;
		vTaskDelay(500/portTICK_RATE_MS);
	}
}
void blinkLED(){
	STM_EVAL_LEDOn(LED_GREEN);
	vTaskDelay(1000/portTICK_RATE_MS);
	STM_EVAL_LEDOff(LED_GREEN);
	vTaskDelay(1000/portTICK_RATE_MS);
}

void vButtonTask(void *pvParameters)
{
	while(true) {
		uint8_t button_pin = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);
		if (button_pin) {
      if(buttonUp)
        buttonHoldTime = 0;
      buttonUp = false;
		} else {
      if (!longClick && !buttonUp && buttonHoldTime >= MIN_PRESS_TIME * 120) {
				if (!singleClick && !doubleClick){
					singleClick = true;
				} else if (singleClick && !doubleClick) {
					singleClick = false;
					doubleClick = true;
				}
      }
			if(!buttonUp) 
				buttonReleaseTime = 0;
			buttonUp = true;
    }
	}
}

void vSoundTask(void *pvParameters) {
	while(true) {
		if (SPI_I2S_GetFlagStatus(CODEC_I2S, SPI_I2S_FLAG_TXE)) {
			SPI_I2S_SendData(CODEC_I2S, sample);
			if (sampleCounter & 0x00000001) {
				if(coffeeIndex == MOCHA)
					sawWave += NOTEFREQUENCY;
				else if(coffeeIndex == ESPRESSO)
					sawWave += 2*NOTEFREQUENCY;
				else if(coffeeIndex == LATTE)
					sawWave += 4*NOTEFREQUENCY;
				
				if (sawWave > 1.0)
					sawWave -= 2.0;

				filteredSaw = updateFilter(&filt, sawWave);
				sample = (int16_t)(NOTEAMPLITUDE*filteredSaw);
			}
			sampleCounter++;
		}
		if (enableSound) {
			if(!sound_init) {
				sound_init = true;
				InitSound();
			}
		} else {
			GPIO_ResetBits(GPIOD, GPIO_Pin_4);
			sound_init = false;
			vTaskDelay(10/portTICK_RATE_MS);
		}
	}
}

void vMain(void *pvParameters) {
	while(true) {
		UpdateMachineStatus();
		ShowLED();
	}
}

void vDispenseMocha(void *pvParameters) {
	int espresso = espressoTime;
	int chocolate = chocolateTime;
	while(true) {
		if(currMode == making) {
			LED_MOCHA_ON;
			LED_ESPRESSO_OFF;
			LED_LATTE_OFF;
		}
		
		while (espresso > 0) {
			currValvePos = VALVE_ESPRESSO;
			changeValve = true;
			blinkLED();
			espresso--;
		}
		
		while (chocolate > 0) {
			currValvePos = VALVE_CHOCO;
			changeValve = true;
			blinkLED();
			chocolate--;
		}
		ResetValve();
		OutputSound(3);
		vTaskDelete(NULL);
	}
}

void vDispenseEspresso(void *pvParameters) {
	int espresso = espressoTime;
	while (true) {
		while (espresso > 0) {
			if(currMode == making) {
				LED_MOCHA_OFF;
				LED_ESPRESSO_ON;
				LED_LATTE_OFF;
			}
			currValvePos = VALVE_ESPRESSO;
			changeValve = true;
			blinkLED();
			espresso--;
		}	
		ResetValve();
		OutputSound(1);
		vTaskDelete(NULL);
	}
}

void vDispenseLatte(void *pvParameters) {
	int espresso = espressoTime;
	int milk = milkTime;
	while (true) {
		if(currMode == making) {
			LED_ESPRESSO_OFF;
			LED_LATTE_ON;
			LED_MOCHA_OFF;
		}
		
		while (espresso > 0) {
			currValvePos = VALVE_ESPRESSO;
			changeValve = true;
			blinkLED();
			espresso--;
		}
		
		while (milk > 0) {
			currValvePos = VALVE_MILK;
			changeValve = true;
			blinkLED();
			milk--;
		}
		ResetValve();
		OutputSound(2);
		vTaskDelete(NULL);
	}
}

void vServoTask(void *pvParameters) {
	while(true) {
		if (changeValve) {
			TIM4->CCR1 = currValvePos;
			changeValve = false;
		}
		vTaskDelay(1000/portTICK_RATE_MS);
	}
}

int main(void)
{
	NVIC_PriorityGroupConfig( NVIC_PriorityGroup_4 );
	
	STM_EVAL_LEDInit(LED_GREEN);
	STM_EVAL_LEDInit(LED_ORANGE);
	STM_EVAL_LEDInit(LED_RED);
	STM_EVAL_LEDInit(LED_BLUE);
	
	STM_EVAL_PBInit(BUTTON_USER, BUTTON_MODE_GPIO);
	
	InitTimers();
	InitButton();
	EnableTimer2Interrupt();
	EnableTimer3Interrupt();
	
	InitSound();
	initFilter(&filt);
	
	currMode = idleMode;
	enableSound = false;
	soundTimer = 0;

	InitServo();
	InitPWMTimer4();
	SetupPWM();
	
	xTaskCreate( vButtonTask, (const char*)"Button Task",
		256, NULL, 0, NULL);
	xTaskCreate( vSoundTask, (const char*)"Sound Task",
		256, NULL, 1, NULL);
	xTaskCreate( vServoTask, (const char*)"Servo Task",
		256, NULL, 1, NULL);
	xTaskCreate( vMain, (const char*)"Main Task",
		256, NULL, 0, NULL);
	
	vTaskStartScheduler();
}
