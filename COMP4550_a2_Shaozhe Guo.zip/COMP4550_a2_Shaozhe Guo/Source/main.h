//Includes
#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "codec.h"

//Defines
#define GREEN GPIO_Pin_12
#define ORANGE GPIO_Pin_13
#define RED GPIO_Pin_14
#define BLUE GPIO_Pin_15

#define LED_GREEN_ON   GPIOD->BSRRL = GPIO_Pin_12;
#define LED_GREEN_OFF  GPIOD->BSRRH = GPIO_Pin_12;
#define LED_ORAGNE_ON   GPIOD->BSRRL = GPIO_Pin_13;
#define LED_ORANGE_OFF  GPIOD->BSRRH = GPIO_Pin_13;
#define LED_RED_ON   GPIOD->BSRRL = GPIO_Pin_14;
#define LED_RED_OFF  GPIOD->BSRRH = GPIO_Pin_14;
#define LED_BLUE_ON   GPIOD->BSRRL = GPIO_Pin_15;
#define LED_BLUE_OFF  GPIOD->BSRRH = GPIO_Pin_15;

#define MOCHA 0
#define ESPRESSO 1
#define LATTE 2

#define MOCHA_LED ORANGE
#define ESPRESSO_LED RED
#define LATTE_LED BLUE

#define LED_MOCHA_ON   GPIOD->BSRRL = GPIO_Pin_13;
#define LED_MOCHA_OFF  GPIOD->BSRRH = GPIO_Pin_13;
#define LED_ESPRESSO_ON   GPIOD->BSRRL = GPIO_Pin_14;
#define LED_ESPRESSO_OFF  GPIOD->BSRRH = GPIO_Pin_14;
#define LED_LATTE_ON   GPIOD->BSRRL = GPIO_Pin_15;
#define LED_LATTE_OFF  GPIOD->BSRRH = GPIO_Pin_15;

#define VALVE_ESPRESSO 900
#define VALVE_MILK 1300
#define VALVE_CHOCO 1700
#define VALVE_OFF 2100

#define LONG_PRESS_TIME 3
#define MIN_PRESS_TIME 0.05
#define DOUBLE_CLICK_TIME 0.5
#define SOUND_OUTPUT 0.3

#define NOTEFREQUENCY 0.05		//frequency of saw wave: f0 = 0.5 * NOTEFREQUENCY * 48000 (=sample rate)
#define NOTEAMPLITUDE 400.0		//amplitude of the saw wave


typedef struct {
	float tabs[8];
	float params[8];
	uint8_t currIndex;
} fir_8;

typedef enum MODE {programming, updateTime, brewing, idleMode, making} mode;
// struct to initialize GPIO pins
GPIO_InitTypeDef GPIO_InitStructure;

volatile uint32_t sampleCounter = 0;
volatile int16_t sample = 0;

double sawWave = 0.0;
float filteredSaw = 0.0;
float updateFilter(fir_8* theFilter, float newValue);
void initFilter(fir_8* theFilter);

void vDispenseLatte(void *pvParameters);
void vDispenseEspresso(void *pvParameters);
void vDispenseMocha(void *pvParameters);
void UpdateMachineStatus(void);
void DisplayCountdown(void);
