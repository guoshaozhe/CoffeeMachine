#include "main.h"

void initSound() {
	SystemInit();

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOD, &GPIO_InitStructure);

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

	codec_init();
	codec_ctrl_init();

	I2S_Cmd(CODEC_I2S, ENABLE);

	initFilter(&filt);
}

float updateFilter(fir_8* filt, float val) {
	uint16_t valIndex;
	uint16_t paramIndex;
	float outval = 0.0;

	valIndex = filt->currIndex;
	filt->tabs[valIndex] = val;

	for (paramIndex=0; paramIndex<8; ++paramIndex)
	{
		outval += (filt->params[paramIndex]) * (filt->tabs[(valIndex+paramIndex)&0x07]);
	}

	++valIndex;
	valIndex &= 0x07;

	filt->currIndex = valIndex;

	return outval;
}

void initFilter(fir_8* theFilter) {
	uint8_t i;

	theFilter->currIndex = 0;

	for (i=0; i<8; i++)
		theFilter->tabs[i] = 0.0;

	theFilter->params[0] = 0.01;
	theFilter->params[1] = 0.05;
	theFilter->params[2] = 0.12;
	theFilter->params[3] = 0.32;
	theFilter->params[4] = 0.32;
	theFilter->params[5] = 0.12;
	theFilter->params[6] = 0.05;
	theFilter->params[7] = 0.01;
}

void InitTimer_2() {
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

  timer_InitStructure.TIM_Prescaler = TIMER_2_PRESCALER;
  timer_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
  timer_InitStructure.TIM_Period = TIMER_2_PERIOD;
  timer_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  timer_InitStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM2, & timer_InitStructure);
  TIM_Cmd(TIM2, ENABLE);
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
}

void EnableTimer2Interrupt() {
  NVIC_InitTypeDef nvicStructure;
  nvicStructure.NVIC_IRQChannel = TIM2_IRQn;
  nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
  nvicStructure.NVIC_IRQChannelSubPriority = 1;
  nvicStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init( & nvicStructure);
}

void TIM2_IRQHandler() {
  if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    		
		timer_button_hold++;
    timer_button_release++;
		
		if(output_sound)
		{
			timer_for_sound++;
		}
		if(timer_for_sound > SOUND_OUTPUT * TIMER_2_FREQUENCY)
		{
			timer_for_sound = 0;
			output_sound = false;
		}
	}
}
 
int main(void)
{
	NVIC_PriorityGroupConfig( NVIC_PriorityGroup_4 );
	
	STM_EVAL_LEDInit(LED_BLUE);
	STM_EVAL_LEDInit(LED_GREEN);
	STM_EVAL_LEDInit(LED_ORANGE);
	STM_EVAL_LEDInit(LED_RED);
	
	STM_EVAL_PBInit(BUTTON_USER, BUTTON_MODE_GPIO);
	
	InitTimer_2();
	EnableTimer2Interrupt();
	initSound();
	initFilter(&filt);
	output_sound = false;
	timer_for_sound = 0;
	 
	xTaskCreate( vSoundTask, (const char*)"Sound Task",
	STACK_SIZE_MIN, NULL, scheduler_priority, NULL);
	
	queue_one = xQueueCreate( 4, sizeof( int ) );
	queue_two = xQueueCreate( 4, sizeof( int ) );
	
	if(queue_one != NULL && queue_two != NULL)
	{
		xTaskCreate( vSeafood, (const char*)"seafood pizza", 
			STACK_SIZE_MIN, NULL, seafood_priority, &seafood_handler );
		xTaskCreate( vVeggie, (const char*)"veggie pizza", 
			STACK_SIZE_MIN, NULL, veggie_priority, &veggie_handler );
		xTaskCreate( vHawaiian, (const char*)"hawaiian chicken pizza", 
			STACK_SIZE_MIN, NULL, hawaiian_priority, &hawaiian_handler );
		xTaskCreate( vPepperoni, (const char*)"pepperoni pizza", 
			STACK_SIZE_MIN, NULL, pepperoni_priority, &peperoni_handler );

		initialize_tasks();
		
		add_new_tasks(curr_time);

		xTaskCreate( vScheduler, (const char*)"fixed priority task",
			STACK_SIZE_MIN, NULL, scheduler_priority, NULL);
		xTaskCreate( vButtonInput, (const char*)"button input",
			STACK_SIZE_MIN, NULL, scheduler_priority, NULL);
		
		vTaskStartScheduler();
	}
}

void initialize_tasks(){
	seafood_task = setup_a_task(seafood_handler, seafood_deadline, seafood_duration, seafood_priority, curr_time); 
	veggie_task = setup_a_task(veggie_handler, veggie_deadline, veggie_duration, veggie_priority, curr_time);
	hawaiian_task = setup_a_task(hawaiian_handler, hawaiian_deadline, hawaiian_duration, hawaiian_priority, curr_time);
	pepperoni_task = setup_a_task(peperoni_handler, pepperoni_deadline, pepperoni_duration, pepperoni_priority, curr_time);
}

void vSeafood(void *pvParameters)
{
	for(;;)
	{
		STM_EVAL_LEDToggle(LED_BLUE);
		vTaskDelay( 400 / portTICK_RATE_MS );
		
	}
}

void vVeggie(void *pvParameters)
{
	for(;;)
	{
		STM_EVAL_LEDToggle(LED_GREEN);
		vTaskDelay( 400 / portTICK_RATE_MS );
	}
}

void vHawaiian(void *pvParameters)
{
	for(;;)
	{
		STM_EVAL_LEDToggle(LED_ORANGE);
		vTaskDelay( 400 / portTICK_RATE_MS );
	}
}

void vPepperoni(void *pvParameters)
{
	for(;;)
	{
		STM_EVAL_LEDToggle(LED_RED);
		vTaskDelay( 400 / portTICK_RATE_MS );
	}
}

void vScheduler(void *pvParameters)
{
	for(;;)
	{
		suspend_all_tasks();	
		if(!start){
			vTaskDelay( 800 / portTICK_RATE_MS );
			continue;
		}
		curr_time++;
		add_new_tasks(curr_time);
		remove_end_tasks();
		switch(curr_mode){
			case FPS:
				process_FPS_task();
				break;
			case EDF:
				process_EDF_task();
				break;
			case LLS:
				process_LLS_task();
				break;
			case EXP:
				process_EXP_task();
				break;
			default:
				break;
		}
		update_exec_time(curr_task);
		
		vTaskDelay( 800 / portTICK_RATE_MS );
		
	}
}

void update_exec_time(int task)
{
	switch (task){
		case seafood_t:
			seafood_task->remain_exec_time--;
			break;
		case veggie_t:
			veggie_task->remain_exec_time--;
			break;
		case hawaiian_t:
			hawaiian_task->remain_exec_time--;
			break;
		case pepperoni_t:
			pepperoni_task->remain_exec_time--;
			break;
		default:
			break;
	}
}

void remove_end_tasks()
{
	int receiveTask = -1;
	const portTickType xTicksToWait = 100/portTICK_RATE_MS;
	bool change_queue = false;
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	QueueHandle_t the_other = use_queue1?queue_two:queue_one;
	
	while(xQueueReceive(current, &receiveTask, xTicksToWait) == pdPASS)
	{
		change_queue = true;
		if(get_remain_time(receiveTask) > 0)
			xQueueSendToBack(the_other, &receiveTask, xTicksToWait);
		else
			output_sound = true;
	}
	use_queue1 = change_queue?!use_queue1:use_queue1;
}

int get_remain_time(int task)
{	
	switch (task){
		case seafood_t:
			return seafood_task->remain_exec_time;
		case veggie_t:
			return veggie_task->remain_exec_time;
		case hawaiian_t:
			return hawaiian_task->remain_exec_time;
		case pepperoni_t:
			return pepperoni_task->remain_exec_time;
		default:
			break;
	}
	return 0;
}

bool task_meet_deadline(int task)
{
	switch (task){
		case seafood_t:
			return seafood_task->deadline <= curr_time;
		case veggie_t:
			return veggie_task->deadline <= curr_time;
		case hawaiian_t:
			return hawaiian_task->deadline <= curr_time;
		case pepperoni_t:
			return pepperoni_task->deadline <= curr_time;
		default:
			break;
	}
	return false;
}

void process_EXP_task()
{
	int receiveTask = -1;
	const portTickType xTicksToWait = 100/portTICK_RATE_MS;
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	
	if (xQueueReceive(current, &receiveTask, xTicksToWait) == pdPASS){
		curr_task = receiveTask;
		xQueueSendToBack(current, &receiveTask, xTicksToWait);
		resume_task(receiveTask);
	}
}

void process_FPS_task()
{
	int receiveTask = -1;
	const portTickType xTicksToWait = 100/portTICK_RATE_MS;
	int highest_priority = 0;
	bool resume =false;
	bool change_queue = false;
	
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	QueueHandle_t the_other = use_queue1?queue_two:queue_one;
	
	while(xQueueReceive(current, &receiveTask, xTicksToWait) == pdPASS)
	{
		change_queue = true;
		if(get_task_priority(receiveTask) > highest_priority)
		{
			highest_priority = get_task_priority(receiveTask);
			curr_task = receiveTask;
			resume = true;
		}
		xQueueSendToBack(the_other, &receiveTask, xTicksToWait);
	}
	use_queue1 = change_queue?!use_queue1:use_queue1;
	if(resume)
		resume_task(curr_task);
}

void process_EDF_task()
{
	int receiveTask = -1;
	const portTickType xTicksToWait = 100/portTICK_RATE_MS;
	int deadline = 1000000;
	bool change_queue = false;
	bool resume = false;
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	QueueHandle_t the_other = use_queue1?queue_two:queue_one;
	while(xQueueReceive(current, &receiveTask, xTicksToWait) == pdPASS)
	{
		change_queue = true;
		if(get_task_ddl(receiveTask) < deadline)
		{
			deadline = get_task_ddl(receiveTask);
			curr_task = receiveTask;
			resume = true;
		}
		else if(get_task_ddl(receiveTask) == deadline)
		{
			curr_task = get_task_priority(curr_task)>get_task_priority(receiveTask)?curr_task:receiveTask;
		}
		xQueueSendToBack(the_other, &receiveTask, xTicksToWait);
	}
	use_queue1 = change_queue?!use_queue1:use_queue1;
	if(resume)
		resume_task(curr_task);
}

void process_LLS_task()
{
	int receiveTask = -1;
	const portTickType xTicksToWait = 100/portTICK_RATE_MS;
	int laxity = 100000;
	bool resume =false;
	bool change_queue = false;
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	QueueHandle_t the_other = use_queue1?queue_two:queue_one;
	
	while(xQueueReceive(current, &receiveTask, xTicksToWait) == pdPASS)
	{
		change_queue = true;
		if(get_task_laxity(receiveTask) < laxity)
		{
			laxity = get_task_laxity(receiveTask);
			curr_task = receiveTask;
			resume = true;
		}
		else if(get_task_laxity(receiveTask) == get_task_laxity(curr_task))
		{
			curr_task = get_task_priority(curr_task)>get_task_priority(receiveTask)?curr_task:receiveTask;
		}
		xQueueSendToBack(the_other, &receiveTask, xTicksToWait);
	}
	use_queue1 = change_queue?!use_queue1:use_queue1;
	if(resume)
		resume_task(curr_task);
}

void resume_task(int task)
{
	switch (task){
		case seafood_t:
			vTaskResume(seafood_task->handler);
			break;
		case veggie_t:
			vTaskResume(veggie_task->handler);
			break;
		case hawaiian_t:
			vTaskResume(hawaiian_task->handler);
			break;
		case pepperoni_t:
			vTaskResume(pepperoni_task->handler);
			break;
		default:
			break;
	}
}

void suspend_task(int task)
{
	switch (task){
		case seafood_t:
			vTaskSuspend(seafood_task->handler);
			break;
		case veggie_t:
			vTaskSuspend(veggie_task->handler);
			break;
		case hawaiian_t:
			vTaskSuspend(hawaiian_task->handler);
			break;
		case pepperoni_t:
			vTaskSuspend(pepperoni_task->handler);
			break;
		default:
			break;
	}
}

void suspend_all_tasks()
{
	vTaskSuspend(seafood_task->handler);
	vTaskSuspend(veggie_task->handler);
	vTaskSuspend(pepperoni_task->handler);
	vTaskSuspend(hawaiian_task->handler);
}

Task* setup_a_task(TaskHandle_t handler, int deadline_time, int execution_time_left, int priority, int start_tim)
{
	Task* task = malloc(sizeof(Task));
	task->handler = handler;
	task->deadline = deadline_time;
	task->remain_exec_time = execution_time_left;
	task->priority = priority;
	task->start_time = start_tim;
	return task;
}

int get_task_priority(int task)
{
	switch (task){
		case seafood_t:
			return seafood_priority;
		case veggie_t:
			return veggie_priority;
		case hawaiian_t:
			return hawaiian_priority;
		case pepperoni_t:
			return pepperoni_priority;
		default:
			break;
	}
	return 0;
}

int get_task_ddl(int task)
{
	switch (task){
		case seafood_t:
			return seafood_task->deadline;
		case veggie_t:
			return veggie_task->deadline;
		case hawaiian_t:
			return hawaiian_task->deadline;
		case pepperoni_t:
			return pepperoni_task->deadline;
		default:
			break;
	}
	return 0;
}

void add_new_tasks(int curr_time)
{
	QueueHandle_t current = use_queue1?queue_one:queue_two;
	if(curr_time%seafood_period == 0)
	{	
		seafood_task->deadline = seafood_deadline + curr_time;
		seafood_task->remain_exec_time = seafood_duration;
		seafood_task->start_time = curr_time;
		xQueueSendToBack(current, (void *) &seafood_t, ( TickType_t ) 10);
	}
	if(curr_time%veggie_period == 0)
	{
		veggie_task->deadline = veggie_deadline + curr_time;
		veggie_task->remain_exec_time = veggie_duration;
		veggie_task->start_time = curr_time;
		xQueueSendToBack(current, (void *) &veggie_t, ( TickType_t ) 10);
	}
	if(curr_time%hawaiian_period == 0)
	{
		hawaiian_task->deadline = hawaiian_deadline + curr_time;
		hawaiian_task->remain_exec_time = hawaiian_duration;
		hawaiian_task->start_time = curr_time;
		xQueueSendToBack(current, (void *) &hawaiian_t, ( TickType_t ) 10);
	}
	if(curr_time%pepperoni_period == 0)
	{		
		pepperoni_task->deadline = pepperoni_deadline + curr_time;
		pepperoni_task->remain_exec_time = pepperoni_duration;
		pepperoni_task->start_time = curr_time;
		xQueueSendToBack(current, (void *) &pepperoni_t, ( TickType_t ) 10);
	}
}

void vSoundTask(void *pvParameters) {
	while(1) {
		if (SPI_I2S_GetFlagStatus(CODEC_I2S, SPI_I2S_FLAG_TXE)) {
			SPI_I2S_SendData(CODEC_I2S, sample);
			if (sampleCounter & 0x00000001) {
				sawWave += NOTEFREQUENCY;
				if (sawWave > 1.0)
					sawWave -= 2.0;

				filteredSaw = updateFilter(&filt, sawWave);
				sample = (int16_t)(NOTEAMPLITUDE*filteredSaw);
			}
			sampleCounter++;
		}
		if (output_sound) {
			if(!sound_init) {
				sound_init = true;
				initSound();
			}
		} else {
			GPIO_ResetBits(GPIOD, GPIO_Pin_4);
			sound_init = false;
			vTaskDelay(10/portTICK_RATE_MS);
		}
	}
}

bool CanUpdateClickState() {
	return (!button_unpressed && 
					timer_button_hold >= MIN_PRESS_TIME * TIMER_2_FREQUENCY);
}

void update_mode()
{
	potential_double_click = (timer_button_release <= (DOUBLE_CLICK_TIME * TIMER_2_FREQUENCY));
	if(start)
	{
		if(single_click && !potential_double_click)
			single_click = false;
		else if(double_click)
		{
			start = false;
			double_click = false;
		}
	} 
	else
	{
		if(single_click && !potential_double_click)
		{
			switch (curr_mode){
				case FPS:
					curr_mode = EDF;
					break;
				case EDF:
					curr_mode = LLS;
					break;
				case LLS:
					curr_mode = EXP;
					break;
				case EXP:
					curr_mode = FPS;
					break;
				default:
					break;
			}			
			single_click = false;
		} 
		else if(double_click)
		{
			start = true;
			STM_EVAL_LEDOff(LED_BLUE);
			STM_EVAL_LEDOff(LED_RED);
			STM_EVAL_LEDOff(LED_GREEN);
			STM_EVAL_LEDOff(LED_ORANGE);
			double_click = false;
		}
	}
}

void update_LED()
{
	if(start){
		return;
	}
	STM_EVAL_LEDOff(LED_ORANGE);
	STM_EVAL_LEDOff(LED_RED);
	STM_EVAL_LEDOff(LED_BLUE);
	STM_EVAL_LEDOff(LED_GREEN);
	switch (curr_mode){
		case FPS:
			STM_EVAL_LEDOn(LED_ORANGE);
			break;
		case EDF:
			STM_EVAL_LEDOn(LED_RED);
			break;
		case LLS:
			STM_EVAL_LEDOn(LED_BLUE);
			break;
		case EXP:
			STM_EVAL_LEDOn(LED_GREEN);
			break;
		default:
			break;
	}
}

void vButtonInput( void * pvParameter)
{
	while(1)
	{
		if(STM_EVAL_PBGetState(BUTTON_USER))
		{
			if(button_unpressed)
				timer_button_hold = 0;
			button_unpressed = false;
		} 
		else 
		{
			if(CanUpdateClickState() && !double_click)
			{
				if (single_click)
					double_click = true;

				single_click = !single_click;
			}
			if(!button_unpressed)
				timer_button_release = 0;
			button_unpressed = true;
		}		
		update_mode();
		update_LED();
		vTaskDelay( 10 / portTICK_RATE_MS );
	}
}

int get_task_laxity(int task)
{
	switch(task){
		case seafood_t:
			return (seafood_task->deadline - curr_time) - seafood_task->remain_exec_time;
		case veggie_t:
			return (veggie_task->deadline - curr_time) - veggie_task->remain_exec_time;
		case hawaiian_t:
			return (hawaiian_task->deadline - curr_time) - hawaiian_task->remain_exec_time;
		case pepperoni_t:
			return (pepperoni_task->deadline - curr_time) - pepperoni_task->remain_exec_time;
		default:
			break;
	}
	return 0;
}

