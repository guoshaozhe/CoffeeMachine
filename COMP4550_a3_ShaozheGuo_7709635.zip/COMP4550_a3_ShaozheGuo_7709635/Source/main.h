//Includes
#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_conf.h"

#include "stdbool.h"
#include "stdlib.h"

#include "codec.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "croutine.h"
#include "discoveryf4utils.h"

#define NOTEFREQUENCY 0.1		//frequency of saw wave: f0 = 0.5 * NOTEFREQUENCY * 48000 (=sample rate)
#define NOTEAMPLITUDE 100.0		//amplitude of the saw wave

typedef struct {
	float tabs[8];
	float params[8];
	uint8_t currIndex;
} fir_8;

#define STACK_SIZE_MIN	128	/* usStackDepth	- the stack size DEFINED IN WORDS.*/

const int seafood_t = 0;
const int veggie_t = 1;
const int hawaiian_t = 2;
const int pepperoni_t = 3;

typedef struct task {
	int start_time;
	int priority;
	int remain_exec_time;
	int deadline;
	TaskHandle_t handler;
} Task;

// struct to initialize GPIO pins
GPIO_InitTypeDef GPIO_InitStructure;

volatile uint32_t sampleCounter = 0;
volatile int16_t sample = 0;

double sawWave = 0.0;

float filteredSaw = 0.0;

TIM_TimeBaseInitTypeDef timer_InitStructure;

// use for setup the clock speed for TIM2
// this timer is used for general purpose timing
const uint16_t TIMER_2_PRESCALER = 232;
const uint16_t TIMER_2_PERIOD = 2999;
const uint16_t TIMER_2_FREQUENCY = 120;

unsigned int timer_button_hold = 0;
unsigned int timer_button_release = 0;

bool button_unpressed = true;
bool start = false;

bool potential_double_click = false;
bool single_click = false;
bool double_click = false;

typedef enum MODE 
{
	FPS, EDF, LLS, EXP
} mode;
mode curr_mode = FPS;

const float MIN_PRESS_TIME = 0.05; // the min single press should need 0.05 second.
const float DOUBLE_CLICK_TIME = 0.5; // double press should be with in 0.5 second.
const float SOUND_OUTPUT = 0.3; // output the sound for 1 second
fir_8 filt;
bool output_sound = false;
int timer_for_sound = 0;
bool sound_init = false;

int curr_time = -1;

TaskHandle_t seafood_handler = NULL;
TaskHandle_t veggie_handler = NULL;
TaskHandle_t hawaiian_handler = NULL;
TaskHandle_t peperoni_handler = NULL;

int seafood_priority = 3;
int veggie_priority = 1;
int hawaiian_priority = 2;
int pepperoni_priority = 2;
int scheduler_priority = 4;

int seafood_deadline = 5;
int veggie_deadline = 10;
int hawaiian_deadline = 10;
int pepperoni_deadline = 15;

int seafood_duration = 3;
int veggie_duration = 4;
int hawaiian_duration = 6;
int pepperoni_duration = 8;

int seafood_period = 20;
int veggie_period = 30;
int hawaiian_period = 40;
int pepperoni_period = 40;

portBASE_TYPE xStatus;

bool use_queue1 = true;
QueueHandle_t queue_one;
QueueHandle_t queue_two;

int curr_task;

Task* seafood_task;
Task* veggie_task;
Task* hawaiian_task;
Task* pepperoni_task;

float updateFilter(fir_8* theFilter, float newValue);

void initFilter(fir_8* theFilter);
void vSoundTask(void *pvParameters);
void vButtonInput(void *pvParameters);
void vSeafood(void *pvParameters);
void vVeggie(void *pvParameters);
void vHawaiian(void *pvParameters);
void vPepperoni(void *pvParameters);
void vScheduler(void *pvParameters);
void initialize_tasks(void);
void add_new_tasks(int);
void update_exec_time(int);
void remove_end_tasks(void);
void process_EXP_task(void);
void process_FPS_task(void);
void process_EDF_task(void);
void process_LLS_task(void);
int get_remain_time(int);
bool task_meet_deadline(int);
int get_task_priority(int);
int get_task_ddl(int);
int get_task_laxity(int);
void suspend_task(int);
void resume_task(int);
void suspend_all_tasks(void);
Task* setup_a_task(TaskHandle_t, int, int, int, int);
